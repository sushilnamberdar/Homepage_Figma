import React from 'react'
import './companys.css';
import logo1 from '../images/company logo/logo1.png';
import logo2 from '../images/company logo/logo2.png';
import logo3 from '../images/company logo/logo3.png';
import logo4 from '../images/company logo/logo4.png';
import logo5 from '../images/company logo/logo5.png';
import logo6 from '../images/company logo/logo6.png';
import logo7 from '../images/company logo/logo7.png';
import logo8 from '../images/company logo/logo8.png';
import logo9 from '../images/company logo/logo9.png';
import logo10 from '../images/company logo/logo10.png';
import logo11 from '../images/company logo/logo11.png';
import logo12 from '../images/company logo/logo12.png';
import logo13 from '../images/company logo/logo13.png';
import logo14 from '../images/company logo/logo14.png';
import logo15 from '../images/company logo/logo15.png';
import logo16 from '../images/company logo/logo16.png';
import logo17 from '../images/company logo/logo17.png';
import logo18 from '../images/company logo/logo18.png';
import logo19 from '../images/company logo/logo19.png';
import logo20 from '../images/company logo/logo20.png';
import logo21 from '../images/company logo/logo21.png';
import logo22 from '../images/company logo/logo22.png';

export const Companys = () => {
  return (
    <>

      <div className='com'>
        <div className='heading'> 
        <div className='mainheading'>Leading Brands</div>
        </div>
        <div className='logos'>
          <div className='image'>
            <img src={logo1} />
          </div>
          <div className='image'>
            <img src={logo2} />
          </div>
          <div className='image'>
            <img src={logo3} />
          </div>
          <div className='image'>
            <img src={logo4} />
          </div>
          <div className='image'>
            <img src={logo5} />
          </div>
          <div className='image'>
            <img src={logo6} />
          </div>
          <div className='image'>
            <img src={logo7} />
          </div>
          <div className='image big'>
            <img src={logo8} />
          </div>
          <div className='image big'>
            <img src={logo9} />
          </div>
          <div className='image big'>
            <img src={logo10} />
          </div>
          <div className='image'>
            <img src={logo11} />
          </div>
          <div className='image'>
            <img src={logo12} />
          </div>
          <div className='image '>
            <img src={logo13} />
          </div>
          <div className='image big'>
            <img src={logo14} />
          </div>
          <div className='image'>
            <img src={logo15} />
          </div>
          <div className='image'>
            <img src={logo16} />
          </div>
          <div className='image'>
            <img src={logo17} />
          </div>
          <div className='image'>
            <img src={logo18} />
          </div>
          <div className='image big'>
            <img src={logo19} />
          </div>
          <div className='image '>
            <img src={logo20} />
          </div>
          <div className='image'>
            <img src={logo21} />
          </div>
          <div className='image big'>
            <img src={logo22} />
          </div>
        </div>
      </div>
    </>
  )
}
