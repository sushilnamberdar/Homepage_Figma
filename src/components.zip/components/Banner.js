import React from 'react'
import banner from '../images/1_TGM_Blog_Banner_Influencer_Marketing.png'
import './banner.css';

export const Banner = () => {
  return (
    <>
    <div className='banner'>
      <img src={banner}/>
    </div>
    </> 
  )
}
